const DATA_BASE = 'TV_STATION'
const BASE_URL = 'mongodb://127.0.0.1:27017'

module.exports = {
    DATA_BASE,
    BASE_URL
}