const DATA_BASE = 'TV_STATION'
const BASE_URL = 'https://evchargingv2-env.eba-pbhtgnvx.eu-north-1.elasticbeanstalk.com'
const DATE_FORMATE = 'DD/MM/YYYY'

module.exports = {
    DATA_BASE,
    BASE_URL,
    DATE_FORMATE
}